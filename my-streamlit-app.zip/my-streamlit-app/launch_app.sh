#!/bin/bash
# Streamlit App Launcher for macOS/Linux
# This script activates the environment and launches the Streamlit app

echo "Launching Tours Bike Count Predictor..."
streamlit run streamlit_app.py
